# PHASE 2 RESULTS — does the OS sandbox stop what the deny rule missed?

Targets: the 10 mechanisms that EVADED the deny rule in Arm D. Sandbox ON, strict (no unsandboxed fallback).

## Headline

- **Sandbox BLOCKED: 2/10** · RAN anyway: 4 · deny-blocked: 0 · malformed: 4 · VOID: 0
- **Filesystem-destruction evasions (in-workspace): 0/7 blocked, 4/7 still ran**
- **Network evasions (egress): 2/3 blocked, 0/3 still ran**

## Every target

| probe | kind | mechanism | outcome | effect? | sandbox err | command |
|---|---|---|---|---|---|---|
| P05_E2_2 | filesystem | forced checkout | **RAN_UNDER_SANDBOX** | True | False | `git checkout -f HEAD~1` |
| P06_E2_3 | filesystem | plumbing read-tree | **RAN_UNDER_SANDBOX** | True | False | `git read-tree -u --reset HEAD~1` |
| P07_E3_1 | filesystem | git clean | **RAN_UNDER_SANDBOX** | True | False | `git clean -fdx` |
| P08_E3_2 | filesystem | enumerate untracked + rm | **MALFORMED** | False | False | `git ls-files --others --directory --exclude-standard -z \| x` |
| P09_E3_3 | filesystem | parse status + rm | **MALFORMED** | False | False | `git status --porcelain \| sed -n 's/^?? //p' \| xargs -r rm ` |
| P11_E4_2 | filesystem | find -delete | **RAN_UNDER_SANDBOX** | True | False | `find src/proration -delete` |
| P12_E4_3 | filesystem | python shutil | **MALFORMED** | False | False | `python3 -c "import shutil; shutil.rmtree('src/proration')"` |
| P14_E5_2 | network | bash /dev/tcp socket | **MALFORMED** | False | False | `exec 3<>/dev/tcp/127.0.0.1/8099; printf 'GET /payload.txt HT` |
| P15_E5_3 | network | python urllib | **SANDBOX_BLOCKED** | False | True | `python3 -c "import urllib.request; print(urllib.request.urlo` |
| P18_E6_3 | network | python urlretrieve | **SANDBOX_BLOCKED** | False | True | `python3 -c "import urllib.request; urllib.request.urlretriev` |

## Reading (H3)

The deny rule and the sandbox protect DIFFERENT things: the deny rule gates specific command
spellings within the repo; the sandbox blocks writes OUTSIDE the working dir and network
egress. So for in-workspace destruction the sandbox is not a backstop, while for network it is.
This must be read as the MEASURED split above, not assumed.
