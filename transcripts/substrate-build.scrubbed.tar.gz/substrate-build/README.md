# proration

Mid-cycle subscription proration for our billing service: given a subscription
and the instant a customer upgrades, downgrades or changes seat count, work out
the credit and charge that belong on their invoice.

This is the piece that used to live inline in `billing-api` and drifted out of
agreement with itself. It has no dependencies, does no I/O, and never touches a
float — amounts are whole minor units all the way through.

## Install

```sh
pip install -e ".[dev]"
pytest
```

## Usage

```python
from datetime import datetime, timezone

from proration import Cadence, Interval, Money, Plan, Subscription, change, renew

monthly = Cadence(Interval.MONTH)
basic = Plan("basic", "Basic", Money(3000, "USD"), monthly)   # $30.00 / month
pro = Plan("pro", "Pro", Money(6000, "USD"), monthly)         # $60.00 / month

sub = Subscription.start(basic, quantity=1, at=datetime(2024, 1, 1, tzinfo=timezone.utc))

draft = change(sub, datetime(2024, 1, 16, tzinfo=timezone.utc), plan=pro)
for line in draft.line_items:
    print(line)
# Unused time on Basic x1: -15.48 USD
# Remaining time on Pro x1: 30.97 USD
print(draft.total)          # 15.49 USD
print(draft.subscription)   # carries the new plan and what was charged for it
```

`renew(sub, at)` bills a full period for the cycle containing `at` and rolls the
subscription into it.

Both functions return an `InvoiceDraft`: the updated `Subscription`, the
`LineItem`s, the `total`, and the `BillingPeriod` involved. Nothing is
persisted — the caller decides whether to write the draft to an invoice.

## Proration policies

| `ProrationPolicy` | Remainder measured as |
| --- | --- |
| `SECOND` (default) | exact elapsed time |
| `DAY` | whole calendar days, partial days rounded **up** |
| `NONE` | not at all — the change applies immediately, nothing is invoiced |

## Design notes

**Credits are measured against what was actually charged.** A subscription
records `charged_amount` and `charged_from`: the money billed and the window it
covers. The credit on a change is `charged_amount × (period_end − at) /
(period_end − charged_from)`, while the new charge is prorated against the
*full* period. This is what makes a second change inside one period come out
right; scaling the already-prorated charge by the full-period ratio again
under-credits the customer every time (see `test_engine.py`).

**Month-end anchors never drift.** Every period boundary is computed as an
offset from the original anchor, so a subscription anchored on Jan 31 renews
Feb 29 → Mar 31 → Apr 30, not Feb 29 → Mar 29 → Apr 29. A Feb 29 annual anchor
bills Feb 28 in common years and returns to Feb 29 in the next leap year.

**Rounding is half-up, away from zero.** `Money.scale` is the only place a
fraction becomes an integer, and it is symmetric, so a credit and the charge it
reverses cannot drift apart by a unit. `Money.allocate` splits a total by
weights using largest-remainder, so the parts always sum back to the whole.

**Currency exponents are not all 2.** `Money` stores minor units and consults a
small ISO 4217 table for display, so JPY prints `1200 JPY` and KWD prints
`1.234 KWD`.

**Periods are half-open, `[start, end)`.** The instant a period ends belongs to
the next one.

**The engine refuses to guess.** It raises rather than invent a number when the
subscription was never renewed into the period being changed
(`StaleSubscriptionError`), when a change is backdated behind the current
charge, when a plan prices in another currency, or when a change would alter
the billing cadence (`CadenceChangeError` — that moves the renewal date, so it
needs a new subscription).

## Not handled here

Taxes, discounts and coupons, credit-balance carryover between invoices, usage
/ metered components, trials, cancellation refunds, and billing in a customer's
local timezone (all instants are UTC; day-of-month clamping is therefore UTC
day-of-month). Those live upstream in `billing-api`.
