from datetime import datetime, timedelta, timezone

import pytest

from proration import (
    AlreadyInvoicedError,
    Cadence,
    CadenceChangeError,
    CurrencyMismatch,
    Interval,
    InvalidPeriodError,
    LineItemKind,
    Money,
    NaiveDatetimeError,
    Plan,
    ProrationPolicy,
    StaleSubscriptionError,
    Subscription,
    change,
    renew,
)

MONTHLY = Cadence(Interval.MONTH)
YEARLY = Cadence(Interval.YEAR)

BASIC = Plan("basic", "Basic", Money(3000, "USD"), MONTHLY)
PRO = Plan("pro", "Pro", Money(6000, "USD"), MONTHLY)
ENTERPRISE = Plan("ent", "Enterprise", Money(9000, "USD"), MONTHLY)
SEAT = Plan("seat", "Team", Money(1000, "USD"), MONTHLY)
FREE = Plan("free", "Free", Money(0, "USD"), MONTHLY)
PRO_EUR = Plan("pro-eur", "Pro (EU)", Money(6000, "EUR"), MONTHLY)
PRO_YEARLY = Plan("pro-yr", "Pro (annual)", Money(60000, "USD"), YEARLY)


def utc(*args):
    return datetime(*args, tzinfo=timezone.utc)


# January 2024 is 31 days long, so a change on the 16th leaves 16 days.
JAN_1 = utc(2024, 1, 1)


def subscribed(plan=BASIC, quantity=1, at=JAN_1):
    return Subscription.start(plan, quantity, at)


def amounts(draft):
    return [line.amount.amount for line in draft.line_items]


# -- happy paths ---------------------------------------------------------


def test_upgrade_credits_the_unused_remainder_and_charges_the_new_plan():
    draft = change(subscribed(), utc(2024, 1, 16), plan=PRO)

    credit, charge = draft.line_items
    assert credit.kind is LineItemKind.CREDIT
    assert credit.amount == Money(-1548, "USD")  # 3000 * 16/31 = 1548.39
    assert credit.plan_id == "basic"
    assert charge.kind is LineItemKind.CHARGE
    assert charge.amount == Money(3097, "USD")  # 6000 * 16/31 = 3096.77
    assert charge.plan_id == "pro"
    assert draft.total == Money(1549, "USD")
    assert not draft.is_credit_balance


def test_line_items_cover_only_the_remainder_of_the_period():
    draft = change(subscribed(), utc(2024, 1, 16), plan=PRO)
    for line in draft.line_items:
        assert line.period.start == utc(2024, 1, 16)
        assert line.period.end == utc(2024, 2, 1)
    assert draft.period.start == JAN_1
    assert draft.period.end == utc(2024, 2, 1)


def test_downgrade_leaves_a_credit_balance():
    draft = change(subscribed(PRO), utc(2024, 1, 16), plan=BASIC)

    assert amounts(draft) == [-3097, 1548]
    assert draft.total == Money(-1549, "USD")
    assert draft.is_credit_balance


def test_change_on_the_first_instant_is_a_clean_swap():
    draft = change(subscribed(), JAN_1, plan=PRO)

    assert amounts(draft) == [-3000, 6000]
    assert draft.total == Money(3000, "USD")
    assert draft.subscription.charged_amount == Money(6000, "USD")
    assert draft.subscription.charged_from == JAN_1


def test_quantity_change_prorates_per_seat():
    draft = change(subscribed(SEAT, quantity=2), utc(2024, 1, 16), quantity=5)

    assert amounts(draft) == [-1032, 2581]  # 2000 and 5000, each * 16/31
    assert draft.subscription.plan is SEAT
    assert draft.subscription.quantity == 5


def test_the_updated_subscription_records_what_was_actually_charged():
    draft = change(subscribed(), utc(2024, 1, 16), plan=PRO)

    assert draft.subscription.plan is PRO
    assert draft.subscription.charged_amount == Money(3097, "USD")
    assert draft.subscription.charged_from == utc(2024, 1, 16)
    assert draft.subscription.anchor == JAN_1  # renewal date is untouched


def test_second_change_in_a_period_does_not_prorate_an_already_prorated_charge():
    first = change(subscribed(), utc(2024, 1, 11), plan=PRO)
    assert first.subscription.charged_amount == Money(4065, "USD")  # 6000 * 21/31

    second = change(first.subscription, utc(2024, 1, 21), plan=ENTERPRISE)

    # The credit is 4065 * 11/21 -- the unused share of the window that charge
    # covered. Scaling it by 11/31 of the whole period instead would credit
    # only 1442 and quietly overbill on every repeat change.
    assert second.line_items[0].amount == Money(-2129, "USD")
    assert second.line_items[1].amount == Money(3194, "USD")  # 9000 * 11/31
    assert second.total == Money(1065, "USD")


def test_a_no_op_change_produces_no_line_items():
    subscription = subscribed(SEAT, quantity=3)
    draft = change(subscription, utc(2024, 1, 16), plan=SEAT, quantity=3)

    assert draft.line_items == ()
    assert draft.total == Money(0, "USD")
    assert draft.subscription is subscription


# -- free plans and zero-value lines -------------------------------------


def test_upgrade_from_a_free_plan_emits_only_a_charge():
    draft = change(subscribed(FREE), utc(2024, 1, 16), plan=PRO)

    assert [line.kind for line in draft.line_items] == [LineItemKind.CHARGE]
    assert draft.total == Money(3097, "USD")


def test_downgrade_to_a_free_plan_emits_only_a_credit():
    draft = change(subscribed(PRO), utc(2024, 1, 16), plan=FREE)

    assert [line.kind for line in draft.line_items] == [LineItemKind.CREDIT]
    assert draft.total == Money(-3097, "USD")
    assert draft.subscription.charged_amount == Money(0, "USD")


# -- policies ------------------------------------------------------------


def test_day_policy_rounds_a_partial_day_up():
    at = utc(2024, 1, 16, 12)  # 15.5 days left

    by_day = change(subscribed(), at, plan=PRO, policy=ProrationPolicy.DAY)
    by_second = change(subscribed(), at, plan=PRO, policy=ProrationPolicy.SECOND)

    assert amounts(by_day) == [-1548, 3097]  # 16/31
    assert amounts(by_second) == [-1500, 3000]  # exactly half


def test_none_policy_swaps_the_plan_without_invoicing():
    draft = change(subscribed(), utc(2024, 1, 16), plan=PRO, policy=ProrationPolicy.NONE)

    assert draft.line_items == ()
    assert draft.total == Money(0, "USD")
    assert draft.subscription.plan is PRO
    # The customer keeps the month they already paid for.
    assert draft.subscription.charged_amount == Money(3000, "USD")
    assert draft.subscription.charged_from == JAN_1


def test_none_policy_still_credits_correctly_on_the_next_change():
    swapped = change(subscribed(), utc(2024, 1, 16), plan=PRO, policy=ProrationPolicy.NONE)
    later = change(swapped.subscription, utc(2024, 1, 21), plan=ENTERPRISE)

    # Credited against the 3000 actually paid, over the whole period.
    assert later.line_items[0].amount == Money(-1065, "USD")  # 3000 * 11/31


# -- renewals ------------------------------------------------------------


def test_renewal_charges_a_full_period():
    draft = renew(subscribed(), utc(2024, 2, 5))

    assert draft.total == Money(3000, "USD")
    assert draft.period.start == utc(2024, 2, 1)
    assert draft.period.end == utc(2024, 3, 1)
    assert draft.subscription.charged_from == utc(2024, 2, 1)
    assert draft.line_items[0].period == draft.period


def test_renewal_is_not_idempotent_by_accident():
    renewed = renew(subscribed(), utc(2024, 2, 5))
    with pytest.raises(AlreadyInvoicedError):
        renew(renewed.subscription, utc(2024, 2, 20))


def test_renewal_of_a_free_plan_emits_no_lines():
    draft = renew(subscribed(FREE), utc(2024, 2, 5))
    assert draft.line_items == ()
    assert draft.total == Money(0, "USD")


def test_changes_work_again_after_renewal():
    renewed = renew(subscribed(), utc(2024, 2, 1))
    draft = change(renewed.subscription, utc(2024, 2, 15), plan=PRO)

    # February 2024 has 29 days; 15 remain from the 15th.
    assert draft.line_items[0].amount == Money(-1552, "USD")  # 3000 * 15/29
    assert draft.line_items[1].amount == Money(3103, "USD")  # 6000 * 15/29


# -- refusals ------------------------------------------------------------


def test_change_in_an_uninvoiced_period_is_refused():
    with pytest.raises(StaleSubscriptionError):
        change(subscribed(), utc(2024, 3, 15), plan=PRO)


def test_change_at_the_exact_period_end_needs_a_renewal_first():
    with pytest.raises(StaleSubscriptionError):
        change(subscribed(), utc(2024, 2, 1), plan=PRO)


def test_backdating_a_change_is_refused():
    changed = change(subscribed(), utc(2024, 1, 16), plan=PRO)
    with pytest.raises(InvalidPeriodError):
        change(changed.subscription, utc(2024, 1, 10), plan=ENTERPRISE)


def test_change_before_the_anchor_is_refused():
    with pytest.raises(InvalidPeriodError):
        change(subscribed(at=utc(2024, 2, 1)), utc(2024, 1, 15), plan=PRO)


def test_cross_currency_change_is_refused():
    with pytest.raises(CurrencyMismatch):
        change(subscribed(), utc(2024, 1, 16), plan=PRO_EUR)


def test_cadence_change_is_refused():
    with pytest.raises(CadenceChangeError):
        change(subscribed(), utc(2024, 1, 16), plan=PRO_YEARLY)


@pytest.mark.parametrize("quantity", [0, -3])
def test_non_positive_quantity_is_refused(quantity):
    with pytest.raises(ValueError):
        change(subscribed(SEAT, quantity=2), utc(2024, 1, 16), quantity=quantity)


def test_naive_datetimes_are_refused_at_the_boundary():
    with pytest.raises(NaiveDatetimeError):
        change(subscribed(), datetime(2024, 1, 16), plan=PRO)
    with pytest.raises(NaiveDatetimeError):
        Subscription.start(BASIC, 1, datetime(2024, 1, 16))


# -- invariants ----------------------------------------------------------


@pytest.mark.parametrize("day", range(1, 32))
def test_credit_never_exceeds_what_was_paid_and_total_is_the_sum(day):
    draft = change(subscribed(PRO), utc(2024, 1, day), plan=BASIC)

    credits = [line for line in draft.line_items if line.kind is LineItemKind.CREDIT]
    for line in credits:
        assert abs(line.amount.amount) <= 6000
    assert draft.total.amount == sum(amounts(draft))


@pytest.mark.parametrize("hours", [0, 1, 371, 743])
def test_reverting_a_change_at_the_same_instant_nets_out_to_zero(hours):
    at = JAN_1 + timedelta(hours=hours)
    up = change(subscribed(), at, plan=PRO)
    down = change(up.subscription, at, plan=BASIC)

    # The full charge just made is credited back, and the new charge is
    # recomputed identically -- no rounding residue may survive the round trip.
    assert up.total + down.total == Money(0, "USD")
    assert -down.line_items[0].amount == up.subscription.charged_amount
    assert down.subscription.charged_amount == -up.line_items[0].amount
