from datetime import datetime, timedelta, timezone

import pytest

from proration import BillingPeriod, Cadence, Interval, advance, period_containing
from proration.errors import InvalidPeriodError, NaiveDatetimeError
from proration.periods import ceil_days, ensure_utc, period_index

MONTHLY = Cadence(Interval.MONTH)
QUARTERLY = Cadence(Interval.MONTH, 3)
YEARLY = Cadence(Interval.YEAR)
FORTNIGHTLY = Cadence(Interval.WEEK, 2)


def utc(*args):
    return datetime(*args, tzinfo=timezone.utc)


def test_ensure_utc_rejects_naive_datetimes():
    with pytest.raises(NaiveDatetimeError):
        ensure_utc(datetime(2024, 1, 1))


def test_ensure_utc_converts_other_zones():
    tokyo = timezone(timedelta(hours=9))
    assert ensure_utc(datetime(2024, 1, 1, 9, tzinfo=tokyo)) == utc(2024, 1, 1, 0)


def test_cadence_requires_a_positive_count():
    with pytest.raises(ValueError):
        Cadence(Interval.MONTH, 0)


def test_cadence_reads_naturally():
    assert str(MONTHLY) == "every month"
    assert str(QUARTERLY) == "every 3 months"


def test_month_end_anchor_does_not_drift():
    # The classic bug: Jan 31 -> Feb 29 -> Feb 29 + 1 month = Mar 29.
    # Offsets are measured from the anchor, so March must come back to the 31st.
    anchor = utc(2024, 1, 31, 12, 0)
    assert advance(anchor, MONTHLY, 1) == utc(2024, 2, 29, 12, 0)
    assert advance(anchor, MONTHLY, 2) == utc(2024, 3, 31, 12, 0)
    assert advance(anchor, MONTHLY, 3) == utc(2024, 4, 30, 12, 0)
    assert advance(anchor, MONTHLY, 4) == utc(2024, 5, 31, 12, 0)


def test_month_end_anchor_clamps_in_a_common_year():
    anchor = utc(2025, 1, 31)
    assert advance(anchor, MONTHLY, 1) == utc(2025, 2, 28)


def test_leap_day_anchor_returns_on_the_next_leap_year():
    anchor = utc(2024, 2, 29)
    assert advance(anchor, YEARLY, 1) == utc(2025, 2, 28)
    assert advance(anchor, YEARLY, 3) == utc(2027, 2, 28)
    assert advance(anchor, YEARLY, 4) == utc(2028, 2, 29)


def test_quarterly_and_weekly_cadences():
    assert advance(utc(2024, 1, 31), QUARTERLY, 1) == utc(2024, 4, 30)
    assert advance(utc(2024, 1, 1), FORTNIGHTLY, 1) == utc(2024, 1, 15)
    assert advance(utc(2024, 1, 1), FORTNIGHTLY, 3) == utc(2024, 2, 12)


def test_advance_accepts_negative_offsets():
    assert advance(utc(2024, 3, 31), MONTHLY, -1) == utc(2024, 2, 29)


def test_period_containing_uses_half_open_bounds():
    anchor = utc(2024, 1, 31, 12, 0)
    start_of_second = utc(2024, 2, 29, 12, 0)

    # The instant a period ends belongs to the next period, not this one.
    assert period_containing(anchor, start_of_second - timedelta(microseconds=1), MONTHLY) == (
        BillingPeriod(anchor, start_of_second)
    )
    assert period_containing(anchor, start_of_second, MONTHLY) == BillingPeriod(
        start_of_second, utc(2024, 3, 31, 12, 0)
    )


def test_period_containing_at_the_anchor_itself():
    anchor = utc(2024, 1, 1)
    assert period_containing(anchor, anchor, MONTHLY).start == anchor


def test_period_index_survives_the_estimate_being_off_by_one():
    # Estimating by calendar month alone says index 1, but the period does not
    # start until the 31st at noon.
    anchor = utc(2024, 1, 31, 12, 0)
    assert period_index(anchor, utc(2024, 2, 1), MONTHLY) == 0
    assert period_index(anchor, utc(2024, 2, 29, 11, 59), MONTHLY) == 0
    assert period_index(anchor, utc(2024, 2, 29, 12, 0), MONTHLY) == 1
    assert period_index(anchor, utc(2025, 1, 31, 12, 0), MONTHLY) == 12


def test_period_before_the_anchor_is_an_error():
    with pytest.raises(InvalidPeriodError):
        period_containing(utc(2024, 6, 1), utc(2024, 5, 31), MONTHLY)


def test_billing_period_rejects_empty_and_inverted_ranges():
    with pytest.raises(InvalidPeriodError):
        BillingPeriod(utc(2024, 1, 1), utc(2024, 1, 1))
    with pytest.raises(InvalidPeriodError):
        BillingPeriod(utc(2024, 2, 1), utc(2024, 1, 1))


def test_billing_period_contains():
    period = BillingPeriod(utc(2024, 1, 1), utc(2024, 2, 1))
    assert period.contains(utc(2024, 1, 1))
    assert period.contains(utc(2024, 1, 31, 23, 59))
    assert not period.contains(utc(2024, 2, 1))
    assert period.duration == timedelta(days=31)


@pytest.mark.parametrize(
    ("span", "expected"),
    [
        (timedelta(0), 0),
        (timedelta(seconds=-5), 0),
        (timedelta(microseconds=1), 1),
        (timedelta(days=1), 1),
        (timedelta(days=1, seconds=1), 2),
        (timedelta(days=20, hours=12), 21),
    ],
)
def test_ceil_days(span, expected):
    assert ceil_days(span) == expected
