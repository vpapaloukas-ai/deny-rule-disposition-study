from fractions import Fraction

import pytest

from proration import CurrencyMismatch, Money, minor_unit_digits
from proration.money import round_half_up, total


def test_normalises_currency_code():
    assert Money(100, "usd").currency == "USD"


@pytest.mark.parametrize("code", ["US", "USDD", "US1", ""])
def test_rejects_non_iso_currency(code):
    with pytest.raises(ValueError):
        Money(100, code)


def test_rejects_float_amounts():
    with pytest.raises(TypeError):
        Money(10.5, "USD")


def test_rejects_bool_amounts():
    # bool is an int subclass; letting it through would silently price at 1 cent.
    with pytest.raises(TypeError):
        Money(True, "USD")


def test_arithmetic_requires_matching_currency():
    with pytest.raises(CurrencyMismatch):
        Money(100, "USD") + Money(100, "EUR")
    with pytest.raises(CurrencyMismatch):
        _ = Money(100, "USD") < Money(100, "EUR")


def test_add_sub_and_negate():
    assert Money(300, "USD") - Money(100, "USD") == Money(200, "USD")
    assert -Money(300, "USD") == Money(-300, "USD")
    assert Money(150, "USD") * 3 == Money(450, "USD")
    assert 3 * Money(150, "USD") == Money(450, "USD")


def test_total_of_empty_sequence_is_typed_zero():
    assert total([], "JPY") == Money(0, "JPY")


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (Fraction(1, 2), 1),
        (Fraction(-1, 2), -1),
        (Fraction(3, 2), 2),
        (Fraction(-3, 2), -2),
        (Fraction(49, 100), 0),
        (Fraction(0), 0),
    ],
)
def test_round_half_up_is_symmetric_about_zero(value, expected):
    assert round_half_up(value) == expected


def test_scale_rounds_half_away_from_zero():
    assert Money(3, "USD").scale(Fraction(1, 2)) == Money(2, "USD")
    assert Money(-3, "USD").scale(Fraction(1, 2)) == Money(-2, "USD")
    # 6000 * 16/31 = 3096.774...
    assert Money(6000, "USD").scale(Fraction(16, 31)) == Money(3097, "USD")


def test_allocate_preserves_the_total():
    parts = Money(1000, "USD").allocate([1, 1, 1])
    assert parts == [Money(334, "USD"), Money(333, "USD"), Money(333, "USD")]
    assert sum(p.amount for p in parts) == 1000


def test_allocate_breaks_ties_by_position():
    assert Money(5, "USD").allocate([3, 7]) == [Money(2, "USD"), Money(3, "USD")]


def test_allocate_handles_negative_totals_symmetrically():
    parts = Money(-1000, "USD").allocate([1, 1, 1])
    assert parts == [Money(-334, "USD"), Money(-333, "USD"), Money(-333, "USD")]


def test_allocate_never_gives_units_to_zero_weights():
    parts = Money(7, "USD").allocate([1, 1, 0])
    assert parts[2] == Money(0, "USD")
    assert sum(p.amount for p in parts) == 7


@pytest.mark.parametrize("weights", [[], [1, -1], [0, 0]])
def test_allocate_rejects_unusable_weights(weights):
    with pytest.raises(ValueError):
        Money(100, "USD").allocate(weights)


def test_minor_unit_digits_knows_the_exceptions():
    assert minor_unit_digits("JPY") == 0
    assert minor_unit_digits("kwd") == 3
    assert minor_unit_digits("USD") == 2


def test_str_respects_currency_exponent():
    assert str(Money(1234, "USD")) == "12.34 USD"
    assert str(Money(-5, "USD")) == "-0.05 USD"
    assert str(Money(1200, "JPY")) == "1200 JPY"
    assert str(Money(1234, "KWD")) == "1.234 KWD"
