from datetime import datetime, timezone

import pytest

from proration import Cadence, CurrencyMismatch, Interval, Money, Plan, Subscription
from proration.errors import InvalidPeriodError

MONTHLY = Cadence(Interval.MONTH)
BASIC = Plan("basic", "Basic", Money(3000, "USD"), MONTHLY)


def utc(*args):
    return datetime(*args, tzinfo=timezone.utc)


def test_plan_exposes_its_currency():
    assert BASIC.currency == "USD"


def test_plan_rejects_a_negative_price():
    with pytest.raises(ValueError):
        Plan("bad", "Bad", Money(-1, "USD"), MONTHLY)


def test_plan_rejects_an_empty_id():
    with pytest.raises(ValueError):
        Plan("", "Nameless", Money(100, "USD"), MONTHLY)


def test_amount_for_multiplies_by_seats():
    assert BASIC.amount_for(4) == Money(12000, "USD")


@pytest.mark.parametrize("quantity", [0, -1])
def test_amount_for_rejects_non_positive_quantities(quantity):
    with pytest.raises(ValueError):
        BASIC.amount_for(quantity)


def test_amount_for_rejects_bool_quantities():
    with pytest.raises(TypeError):
        BASIC.amount_for(True)


def test_start_bills_the_first_period_in_full():
    subscription = Subscription.start(BASIC, 2, utc(2024, 1, 31))

    assert subscription.charged_amount == Money(6000, "USD")
    assert subscription.charged_from == subscription.anchor == utc(2024, 1, 31)


def test_period_at_follows_the_anchor():
    subscription = Subscription.start(BASIC, 1, utc(2024, 1, 31))
    period = subscription.period_at(utc(2024, 2, 15))

    assert period.start == utc(2024, 1, 31)
    assert period.end == utc(2024, 2, 29)


def test_subscription_rejects_a_charge_in_another_currency():
    with pytest.raises(CurrencyMismatch):
        Subscription(
            plan=BASIC,
            quantity=1,
            anchor=utc(2024, 1, 1),
            charged_amount=Money(3000, "EUR"),
            charged_from=utc(2024, 1, 1),
        )


def test_subscription_rejects_a_charge_starting_before_the_anchor():
    with pytest.raises(InvalidPeriodError):
        Subscription(
            plan=BASIC,
            quantity=1,
            anchor=utc(2024, 2, 1),
            charged_amount=Money(3000, "USD"),
            charged_from=utc(2024, 1, 1),
        )


def test_with_charge_leaves_the_anchor_alone():
    subscription = Subscription.start(BASIC, 1, utc(2024, 1, 1))
    updated = subscription.with_charge(Money(1500, "USD"), utc(2024, 1, 16))

    assert updated.anchor == utc(2024, 1, 1)
    assert updated.charged_amount == Money(1500, "USD")
    assert updated.charged_from == utc(2024, 1, 16)
    assert subscription.charged_amount == Money(3000, "USD")  # original untouched
