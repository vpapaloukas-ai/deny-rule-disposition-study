"""Exact money in integer minor units.

Floats are never used. Amounts are stored as whole minor units (cents, fils,
yen) and every operation that could produce a fraction goes through
:meth:`Money.scale` (half-up, away from zero) or :meth:`Money.allocate`
(largest-remainder, sum-preserving).
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from fractions import Fraction

from .errors import CurrencyMismatch

DEFAULT_MINOR_UNIT_DIGITS = 2

#: ISO 4217 currencies whose exponent is not the usual 2. Anything absent from
#: this table is assumed to have 2 decimal places, which holds for the vast
#: majority of codes we invoice in.
MINOR_UNIT_DIGITS: dict[str, int] = {
    "BHD": 3,
    "CLP": 0,
    "IQD": 3,
    "ISK": 0,
    "JOD": 3,
    "JPY": 0,
    "KRW": 0,
    "KWD": 3,
    "OMR": 3,
    "TND": 3,
    "UGX": 0,
    "VND": 0,
}


def minor_unit_digits(currency: str) -> int:
    """Number of decimal places used when displaying ``currency``."""
    return MINOR_UNIT_DIGITS.get(currency.upper(), DEFAULT_MINOR_UNIT_DIGITS)


def round_half_up(value: Fraction) -> int:
    """Round a fraction to the nearest integer, halves going away from zero.

    Away-from-zero (rather than banker's rounding) is what our finance team
    reconciles against, and it keeps ``round(-x) == -round(x)`` so a credit and
    the charge it reverses cannot drift apart by a unit.
    """
    negative = value < 0
    magnitude = -value if negative else value
    whole, remainder = divmod(magnitude, 1)
    if remainder >= Fraction(1, 2):
        whole += 1
    whole = int(whole)
    return -whole if negative else whole


@dataclass(frozen=True, order=False)
class Money:
    """An amount of ``currency`` expressed as a whole number of minor units."""

    amount: int
    currency: str

    def __post_init__(self) -> None:
        if isinstance(self.amount, bool) or not isinstance(self.amount, int):
            raise TypeError(f"amount must be an int of minor units, got {self.amount!r}")
        code = self.currency
        if not isinstance(code, str) or len(code) != 3 or not code.isalpha():
            raise ValueError(f"currency must be a 3-letter ISO 4217 code, got {code!r}")
        object.__setattr__(self, "currency", code.upper())

    # -- construction ----------------------------------------------------

    @classmethod
    def zero(cls, currency: str) -> Money:
        return cls(0, currency)

    # -- helpers ---------------------------------------------------------

    def _same_currency(self, other: Money) -> None:
        if self.currency != other.currency:
            raise CurrencyMismatch(
                f"cannot combine {self.currency} with {other.currency}"
            )

    @property
    def is_zero(self) -> bool:
        return self.amount == 0

    @property
    def is_negative(self) -> bool:
        return self.amount < 0

    # -- arithmetic ------------------------------------------------------

    def __add__(self, other: Money) -> Money:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return Money(self.amount + other.amount, self.currency)

    def __sub__(self, other: Money) -> Money:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return Money(self.amount - other.amount, self.currency)

    def __neg__(self) -> Money:
        return Money(-self.amount, self.currency)

    def __abs__(self) -> Money:
        return Money(abs(self.amount), self.currency)

    def __mul__(self, factor: int) -> Money:
        if isinstance(factor, bool) or not isinstance(factor, int):
            return NotImplemented
        return Money(self.amount * factor, self.currency)

    __rmul__ = __mul__

    def __lt__(self, other: Money) -> bool:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return self.amount < other.amount

    def __le__(self, other: Money) -> bool:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return self.amount <= other.amount

    def __gt__(self, other: Money) -> bool:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return self.amount > other.amount

    def __ge__(self, other: Money) -> bool:
        if not isinstance(other, Money):
            return NotImplemented
        self._same_currency(other)
        return self.amount >= other.amount

    def scale(self, ratio: Fraction | int) -> Money:
        """Multiply by an exact ratio, rounding half away from zero."""
        return Money(round_half_up(self.amount * Fraction(ratio)), self.currency)

    def allocate(self, weights: Sequence[int]) -> list[Money]:
        """Split into parts proportional to ``weights`` with no unit lost.

        Uses the largest-remainder method: every part is the floor of its exact
        share, then the leftover units go to the parts with the largest
        remainders (ties broken by position). ``sum(result) == self`` always.
        """
        weights = list(weights)
        if not weights:
            raise ValueError("allocate() requires at least one weight")
        if any(isinstance(w, bool) or not isinstance(w, int) for w in weights):
            raise TypeError("weights must be ints")
        if any(w < 0 for w in weights):
            raise ValueError("weights must be non-negative")
        total_weight = sum(weights)
        if total_weight == 0:
            raise ValueError("weights must not sum to zero")

        sign = -1 if self.amount < 0 else 1
        gross = abs(self.amount)
        shares = [gross * w // total_weight for w in weights]
        leftover = gross - sum(shares)
        # Largest remainder first; ``-remainder`` keeps the sort stable on ties.
        order = sorted(
            range(len(weights)),
            key=lambda i: (-((gross * weights[i]) % total_weight), i),
        )
        for index in order[:leftover]:
            shares[index] += 1
        return [Money(sign * share, self.currency) for share in shares]

    # -- display ---------------------------------------------------------

    def __str__(self) -> str:
        digits = minor_unit_digits(self.currency)
        sign = "-" if self.amount < 0 else ""
        magnitude = abs(self.amount)
        if digits == 0:
            return f"{sign}{magnitude} {self.currency}"
        unit = 10**digits
        whole, fraction = divmod(magnitude, unit)
        return f"{sign}{whole}.{fraction:0{digits}d} {self.currency}"

    def __repr__(self) -> str:
        return f"Money({self.amount}, {self.currency!r})"


def total(amounts: Sequence[Money], currency: str) -> Money:
    """Sum ``amounts``, returning zero in ``currency`` for an empty sequence."""
    result = Money.zero(currency)
    for amount in amounts:
        result = result + amount
    return result
