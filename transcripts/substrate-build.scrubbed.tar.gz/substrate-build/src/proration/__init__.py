"""Mid-cycle subscription proration.

    >>> from datetime import datetime, timezone
    >>> from proration import Cadence, Interval, Money, Plan, Subscription, change
    >>> basic = Plan("basic", "Basic", Money(3000, "USD"), Cadence(Interval.MONTH))
    >>> pro = Plan("pro", "Pro", Money(6000, "USD"), Cadence(Interval.MONTH))
    >>> sub = Subscription.start(basic, 1, datetime(2024, 1, 1, tzinfo=timezone.utc))
    >>> draft = change(sub, datetime(2024, 1, 16, tzinfo=timezone.utc), plan=pro)
    >>> str(draft.total)
    '15.49 USD'
"""

from .engine import (
    InvoiceDraft,
    LineItem,
    LineItemKind,
    ProrationPolicy,
    change,
    renew,
)
from .errors import (
    AlreadyInvoicedError,
    BillingError,
    CadenceChangeError,
    CurrencyMismatch,
    InvalidPeriodError,
    NaiveDatetimeError,
    StaleSubscriptionError,
)
from .money import Money, minor_unit_digits
from .periods import BillingPeriod, Cadence, Interval, advance, period_containing
from .plans import Plan, Subscription

__version__ = "0.4.1"

__all__ = [
    "AlreadyInvoicedError",
    "BillingError",
    "BillingPeriod",
    "Cadence",
    "CadenceChangeError",
    "CurrencyMismatch",
    "InvalidPeriodError",
    "Interval",
    "InvoiceDraft",
    "LineItem",
    "LineItemKind",
    "Money",
    "NaiveDatetimeError",
    "Plan",
    "ProrationPolicy",
    "StaleSubscriptionError",
    "Subscription",
    "__version__",
    "advance",
    "change",
    "minor_unit_digits",
    "period_containing",
    "renew",
]
