"""Billing cadences and the periods they generate.

All instants are timezone-aware and normalised to UTC. Day-of-month clamping
(the "31st of every month" problem) is always resolved against the *original*
anchor, never against the previous period's clamped date -- otherwise a
subscription anchored on Jan 31 would drift to the 28th forever after its first
February.
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum

from .errors import InvalidPeriodError, NaiveDatetimeError

UTC = timezone.utc


class Interval(str, Enum):
    WEEK = "week"
    MONTH = "month"
    YEAR = "year"


def ensure_utc(value: datetime, *, name: str = "datetime") -> datetime:
    """Validate that ``value`` is aware and return it converted to UTC."""
    if not isinstance(value, datetime):
        raise TypeError(f"{name} must be a datetime, got {type(value).__name__}")
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        raise NaiveDatetimeError(
            f"{name} must be timezone-aware; billing math on naive datetimes is ambiguous"
        )
    return value.astimezone(UTC)


@dataclass(frozen=True)
class Cadence:
    """How often a subscription renews, e.g. every 3 months."""

    interval: Interval
    count: int = 1

    def __post_init__(self) -> None:
        if isinstance(self.count, bool) or not isinstance(self.count, int):
            raise TypeError("count must be an int")
        if self.count < 1:
            raise ValueError("count must be at least 1")
        object.__setattr__(self, "interval", Interval(self.interval))

    def __str__(self) -> str:
        if self.count == 1:
            return f"every {self.interval.value}"
        return f"every {self.count} {self.interval.value}s"


@dataclass(frozen=True)
class BillingPeriod:
    """A half-open interval ``[start, end)`` that a charge covers."""

    start: datetime
    end: datetime

    def __post_init__(self) -> None:
        start = ensure_utc(self.start, name="start")
        end = ensure_utc(self.end, name="end")
        if end <= start:
            raise InvalidPeriodError(f"period end {end.isoformat()} must be after start")
        object.__setattr__(self, "start", start)
        object.__setattr__(self, "end", end)

    @property
    def duration(self) -> timedelta:
        return self.end - self.start

    def contains(self, at: datetime) -> bool:
        at = ensure_utc(at, name="at")
        return self.start <= at < self.end

    def __str__(self) -> str:
        return f"{self.start.isoformat()} -> {self.end.isoformat()}"


def _add_months(anchor: datetime, months: int) -> datetime:
    """Shift ``anchor`` by whole months, clamping to the target month's length."""
    total = anchor.year * 12 + (anchor.month - 1) + months
    year, month_index = divmod(total, 12)
    month = month_index + 1
    day = min(anchor.day, calendar.monthrange(year, month)[1])
    return anchor.replace(year=year, month=month, day=day)


def advance(anchor: datetime, cadence: Cadence, periods: int) -> datetime:
    """Return the instant ``periods`` cadence-steps away from ``anchor``.

    ``periods`` may be negative. Because the offset is always measured from
    ``anchor`` itself, clamping never compounds.
    """
    anchor = ensure_utc(anchor, name="anchor")
    steps = cadence.count * periods
    if cadence.interval is Interval.WEEK:
        return anchor + timedelta(weeks=steps)
    if cadence.interval is Interval.MONTH:
        return _add_months(anchor, steps)
    return _add_months(anchor, steps * 12)


def _estimate_index(anchor: datetime, at: datetime, cadence: Cadence) -> int:
    """Cheap lower-ish bound on the period index containing ``at``."""
    if cadence.interval is Interval.WEEK:
        return (at - anchor) // timedelta(weeks=cadence.count)
    months = (at.year - anchor.year) * 12 + (at.month - anchor.month)
    if cadence.interval is Interval.YEAR:
        return months // (12 * cadence.count)
    return months // cadence.count


def period_index(anchor: datetime, at: datetime, cadence: Cadence) -> int:
    """Index of the period containing ``at``, counting from 0 at ``anchor``."""
    anchor = ensure_utc(anchor, name="anchor")
    at = ensure_utc(at, name="at")
    if at < anchor:
        raise InvalidPeriodError(
            f"{at.isoformat()} precedes the subscription anchor {anchor.isoformat()}"
        )
    index = _estimate_index(anchor, at, cadence)
    # The estimate ignores time-of-day and day clamping, so it can be off by
    # one in either direction. Correct it; each loop runs at most a step or two.
    while index > 0 and advance(anchor, cadence, index) > at:
        index -= 1
    while advance(anchor, cadence, index + 1) <= at:
        index += 1
    return index


def period_containing(anchor: datetime, at: datetime, cadence: Cadence) -> BillingPeriod:
    """The billing period that covers ``at`` for a subscription anchored at ``anchor``."""
    index = period_index(anchor, at, cadence)
    return BillingPeriod(
        advance(anchor, cadence, index),
        advance(anchor, cadence, index + 1),
    )


def ceil_days(span: timedelta) -> int:
    """Whole days in ``span``, rounding any partial day up. Never negative."""
    microseconds = span // timedelta(microseconds=1)
    if microseconds <= 0:
        return 0
    return -(-microseconds // 86_400_000_000)
