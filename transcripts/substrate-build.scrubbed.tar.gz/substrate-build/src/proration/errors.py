"""Exception hierarchy for the proration engine.

Everything raised on purpose by this package derives from :class:`BillingError`,
so callers can wrap a whole invoicing run in a single ``except``.
"""

from __future__ import annotations


class BillingError(Exception):
    """Base class for all errors raised by this package."""


class CurrencyMismatch(BillingError):
    """Two monetary values (or a plan and a subscription) use different currencies."""


class NaiveDatetimeError(BillingError, ValueError):
    """A timezone-naive datetime was supplied where an aware one is required."""


class InvalidPeriodError(BillingError, ValueError):
    """A billing period is malformed, or an instant falls outside the allowed range."""


class StaleSubscriptionError(BillingError):
    """The subscription's last charge predates the period being operated on.

    This means a renewal was missed: the engine refuses to guess what was
    actually invoiced for the current period. Call :func:`proration.renew`
    for the intervening periods first.
    """


class AlreadyInvoicedError(BillingError):
    """The subscription has already been invoiced for the period containing ``at``."""


class CadenceChangeError(BillingError):
    """A plan change would alter the billing cadence.

    Switching monthly -> yearly moves the renewal date, so it cannot be
    expressed as a credit/charge pair inside the current period. Cancel and
    re-subscribe (or start a new subscription with a new anchor) instead.
    """
