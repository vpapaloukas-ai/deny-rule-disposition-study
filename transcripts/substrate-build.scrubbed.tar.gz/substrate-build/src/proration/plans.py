"""Plans and subscriptions.

A :class:`Subscription` deliberately carries what was *actually invoiced* for
the coverage window it is currently in (``charged_amount`` from
``charged_from``) rather than deriving it from the plan price. Without that,
the second plan change inside a single period would credit the customer for a
full month they never paid for.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime

from .errors import CurrencyMismatch, InvalidPeriodError
from .money import Money
from .periods import BillingPeriod, Cadence, ensure_utc, period_containing


@dataclass(frozen=True)
class Plan:
    """A priced offering billed on a fixed cadence."""

    id: str
    name: str
    unit_amount: Money
    cadence: Cadence

    def __post_init__(self) -> None:
        if not self.id:
            raise ValueError("plan id must not be empty")
        if not isinstance(self.unit_amount, Money):
            raise TypeError("unit_amount must be a Money")
        if self.unit_amount.is_negative:
            raise ValueError("unit_amount must not be negative")

    @property
    def currency(self) -> str:
        return self.unit_amount.currency

    def amount_for(self, quantity: int) -> Money:
        """Undiscounted list price for ``quantity`` seats for one full period."""
        if isinstance(quantity, bool) or not isinstance(quantity, int):
            raise TypeError("quantity must be an int")
        if quantity < 1:
            raise ValueError("quantity must be at least 1")
        return self.unit_amount * quantity


@dataclass(frozen=True)
class Subscription:
    """A customer's active plan plus the state proration needs.

    Attributes:
        anchor: Instant the subscription started; fixes every future renewal date.
        charged_from: Start of the window covered by ``charged_amount``. Equals
            the period start after a renewal, or the change instant after a
            mid-period plan change.
        charged_amount: What the customer was actually billed for
            ``[charged_from, period_end)``.
    """

    plan: Plan
    quantity: int
    anchor: datetime
    charged_amount: Money
    charged_from: datetime

    def __post_init__(self) -> None:
        if isinstance(self.quantity, bool) or not isinstance(self.quantity, int):
            raise TypeError("quantity must be an int")
        if self.quantity < 1:
            raise ValueError("quantity must be at least 1")
        anchor = ensure_utc(self.anchor, name="anchor")
        charged_from = ensure_utc(self.charged_from, name="charged_from")
        if charged_from < anchor:
            raise InvalidPeriodError("charged_from must not precede the anchor")
        if self.charged_amount.currency != self.plan.currency:
            raise CurrencyMismatch(
                f"charged_amount is {self.charged_amount.currency} "
                f"but the plan prices in {self.plan.currency}"
            )
        object.__setattr__(self, "anchor", anchor)
        object.__setattr__(self, "charged_from", charged_from)

    @classmethod
    def start(cls, plan: Plan, quantity: int, at: datetime) -> Subscription:
        """Begin a subscription at ``at``, billed in full for the first period."""
        at = ensure_utc(at, name="at")
        return cls(
            plan=plan,
            quantity=quantity,
            anchor=at,
            charged_amount=plan.amount_for(quantity),
            charged_from=at,
        )

    @property
    def currency(self) -> str:
        return self.plan.currency

    def period_at(self, at: datetime) -> BillingPeriod:
        """The billing period covering ``at``."""
        return period_containing(self.anchor, at, self.plan.cadence)

    def with_charge(self, amount: Money, charged_from: datetime) -> Subscription:
        """Copy with a new coverage window recorded."""
        return replace(self, charged_amount=amount, charged_from=charged_from)
