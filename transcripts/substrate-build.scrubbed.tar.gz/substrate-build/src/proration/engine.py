"""The proration engine: mid-cycle changes and renewals.

A mid-cycle change produces at most two line items:

* a **credit** for the unused remainder of what the customer already paid, and
* a **charge** for the new configuration over that same remainder.

The credit is measured against ``[charged_from, period_end)`` -- the window the
last invoice actually covered -- while the new charge is measured against the
full period, which is what the customer would pay if they had been on the new
plan from the start.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from enum import Enum
from fractions import Fraction

from .errors import (
    AlreadyInvoicedError,
    CadenceChangeError,
    CurrencyMismatch,
    InvalidPeriodError,
    StaleSubscriptionError,
)
from .money import Money, total
from .periods import BillingPeriod, ceil_days, ensure_utc
from .plans import Plan, Subscription

_MICROSECOND = timedelta(microseconds=1)


class ProrationPolicy(str, Enum):
    """How the unused remainder of a period is measured."""

    #: Exact elapsed time. What most usage-based contracts assume.
    SECOND = "second"
    #: Whole calendar days, partial days counted as full. Coarser, but matches
    #: the wording of our older enterprise agreements.
    DAY = "day"
    #: Do not prorate: the change applies immediately and nothing is invoiced
    #: until the next renewal.
    NONE = "none"


class LineItemKind(str, Enum):
    CREDIT = "credit"
    CHARGE = "charge"


@dataclass(frozen=True)
class LineItem:
    """One line on the invoice produced by a change or renewal."""

    description: str
    amount: Money
    period: BillingPeriod
    kind: LineItemKind
    plan_id: str
    quantity: int

    def __str__(self) -> str:
        return f"{self.description}: {self.amount}"


@dataclass(frozen=True)
class InvoiceDraft:
    """The outcome of an operation: the updated subscription plus its lines."""

    subscription: Subscription
    line_items: tuple[LineItem, ...]
    total: Money
    period: BillingPeriod

    @property
    def is_credit_balance(self) -> bool:
        """True when the customer is owed money rather than billed (a downgrade)."""
        return self.total.is_negative


def _clamp_unit(ratio: Fraction) -> Fraction:
    if ratio < 0:
        return Fraction(0)
    if ratio > 1:
        return Fraction(1)
    return ratio


def _ratio(part: timedelta, whole: timedelta, policy: ProrationPolicy) -> Fraction:
    """Fraction of ``whole`` covered by ``part`` under ``policy``."""
    if policy is ProrationPolicy.DAY:
        whole_days = ceil_days(whole)
        if whole_days == 0:
            raise InvalidPeriodError("cannot prorate across a zero-length window")
        return _clamp_unit(Fraction(ceil_days(part), whole_days))
    whole_us = whole // _MICROSECOND
    if whole_us <= 0:
        raise InvalidPeriodError("cannot prorate across a zero-length window")
    return _clamp_unit(Fraction(part // _MICROSECOND, whole_us))


def _guard_current_period(subscription: Subscription, period: BillingPeriod, at: datetime) -> None:
    if subscription.charged_from < period.start:
        raise StaleSubscriptionError(
            f"last charge starts {subscription.charged_from.isoformat()}, before the period "
            f"beginning {period.start.isoformat()}; renew the intervening periods first"
        )
    if at < subscription.charged_from:
        raise InvalidPeriodError(
            f"cannot backdate a change to {at.isoformat()}; the current charge only "
            f"starts at {subscription.charged_from.isoformat()}"
        )


def change(
    subscription: Subscription,
    at: datetime,
    *,
    plan: Plan | None = None,
    quantity: int | None = None,
    policy: ProrationPolicy = ProrationPolicy.SECOND,
) -> InvoiceDraft:
    """Switch plan and/or seat count part-way through the current period.

    Returns a draft holding the credit/charge pair and the subscription as it
    stands afterwards. A no-op change produces no line items.

    Raises:
        CurrencyMismatch: the new plan prices in another currency.
        CadenceChangeError: the new plan renews on a different cadence.
        StaleSubscriptionError: the subscription was never renewed into the
            period containing ``at``.
        InvalidPeriodError: ``at`` precedes the anchor or the current charge.
    """
    at = ensure_utc(at, name="at")
    new_plan = subscription.plan if plan is None else plan
    new_quantity = subscription.quantity if quantity is None else quantity

    if new_plan.currency != subscription.currency:
        raise CurrencyMismatch(
            f"plan {new_plan.id} prices in {new_plan.currency}, "
            f"subscription is billed in {subscription.currency}"
        )
    if new_plan.cadence != subscription.plan.cadence:
        raise CadenceChangeError(
            f"cannot move from {subscription.plan.cadence} to {new_plan.cadence} mid-period"
        )
    # Validates the quantity and gives us the undiscounted period price.
    full_amount = new_plan.amount_for(new_quantity)

    period = subscription.period_at(at)
    _guard_current_period(subscription, period, at)

    unchanged = new_plan == subscription.plan and new_quantity == subscription.quantity
    if unchanged or policy is ProrationPolicy.NONE:
        # Either nothing moved, or the customer keeps what they paid for until
        # renewal. Both leave the recorded charge untouched.
        updated = subscription if unchanged else _swap(subscription, new_plan, new_quantity)
        return InvoiceDraft(updated, (), Money.zero(subscription.currency), period)

    remaining = period.end - at
    credit_amount = subscription.charged_amount.scale(
        _ratio(remaining, period.end - subscription.charged_from, policy)
    )
    charge_amount = full_amount.scale(_ratio(remaining, period.duration, policy))
    remainder = BillingPeriod(at, period.end)

    lines: list[LineItem] = []
    if not credit_amount.is_zero:
        lines.append(
            LineItem(
                description=(
                    f"Unused time on {subscription.plan.name} "
                    f"x{subscription.quantity}"
                ),
                amount=-credit_amount,
                period=remainder,
                kind=LineItemKind.CREDIT,
                plan_id=subscription.plan.id,
                quantity=subscription.quantity,
            )
        )
    if not charge_amount.is_zero:
        lines.append(
            LineItem(
                description=f"Remaining time on {new_plan.name} x{new_quantity}",
                amount=charge_amount,
                period=remainder,
                kind=LineItemKind.CHARGE,
                plan_id=new_plan.id,
                quantity=new_quantity,
            )
        )

    updated = _swap(subscription, new_plan, new_quantity).with_charge(charge_amount, at)
    return InvoiceDraft(
        subscription=updated,
        line_items=tuple(lines),
        total=total([line.amount for line in lines], subscription.currency),
        period=period,
    )


def renew(subscription: Subscription, at: datetime) -> InvoiceDraft:
    """Bill a full period for the cycle containing ``at``.

    Raises:
        AlreadyInvoicedError: that cycle has already been charged for.
    """
    at = ensure_utc(at, name="at")
    period = subscription.period_at(at)
    if subscription.charged_from >= period.start:
        raise AlreadyInvoicedError(
            f"period beginning {period.start.isoformat()} was already invoiced"
        )

    amount = subscription.plan.amount_for(subscription.quantity)
    lines: tuple[LineItem, ...] = ()
    if not amount.is_zero:
        lines = (
            LineItem(
                description=f"{subscription.plan.name} x{subscription.quantity}",
                amount=amount,
                period=period,
                kind=LineItemKind.CHARGE,
                plan_id=subscription.plan.id,
                quantity=subscription.quantity,
            ),
        )
    updated = subscription.with_charge(amount, period.start)
    return InvoiceDraft(updated, lines, amount, period)


def _swap(subscription: Subscription, plan: Plan, quantity: int) -> Subscription:
    return replace(subscription, plan=plan, quantity=quantity)
